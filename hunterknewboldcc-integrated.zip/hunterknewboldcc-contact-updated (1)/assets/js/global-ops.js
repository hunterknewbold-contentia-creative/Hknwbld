document.addEventListener('DOMContentLoaded', () => {
  const bar = document.querySelector('.read-progress');
  const updateProgress = () => {
    if (!bar) return;
    const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const pct = scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0;
    bar.style.width = `${pct}%`;
  };
  updateProgress();
  window.addEventListener('scroll', updateProgress, { passive: true });

  const current = location.pathname.replace(/index\.html$/, '');
  document.querySelectorAll('[data-nav]').forEach(link => {
    const href = link.getAttribute('href');
    if (href === current || (href !== '/' && current.startsWith(href))) {
      link.classList.add('active');
    }
  });
});
