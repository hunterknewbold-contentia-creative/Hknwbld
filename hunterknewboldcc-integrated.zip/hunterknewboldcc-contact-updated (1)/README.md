# hunterknewboldcc.com — refreshed site package

This package is a Netlify-ready static site for a personal brand website built around a retro terminal / classified dossier aesthetic.

## What was improved

- stronger homepage positioning and calls to action
- revised page titles and meta descriptions across core pages and blog posts
- Open Graph, Twitter, canonical, and JSON-LD metadata
- internal linking on published blog posts via Related Files sections
- improved About, Portfolio, and Contact pages
- Netlify-ready contact form with honeypot and thank-you page
- SEO draft post placeholders marked `noindex` until expanded
- updated sitemap for live pages only

## Draft placeholder pages

The following pages are included as structured drafts and are intentionally marked `noindex,follow` so they do not dilute SEO until they are fully written:

- /blog/retro-terminal-design/
- /blog/behavioral-science-in-design/
- /blog/classified-dossier-visuals/
- /blog/brutalist-design-principles/
- /blog/signal-structure-design/
- /blog/narrative-coherence-in-design/

## Deploying

1. Upload the site folder to Netlify, or drag the ZIP into a new manual deploy.
2. Verify your public contact links and form settings before going live.
3. Expand draft pages into full posts when ready, then remove the `noindex` directive.


## Public contact wired in
- Email: hunterknewbold@hunterknewboldcc.com
- Instagram: @hunterknewbold
- X: @HunterNewb92822
